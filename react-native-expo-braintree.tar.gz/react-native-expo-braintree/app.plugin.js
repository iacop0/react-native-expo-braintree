module.exports = require('./lib/commonjs/plugin/withExpoBraintree');
